<?php

$text = array(
   'pl' => array(
   	  'main_site' => 'Strona Główna', 
		  'method' => 'Metoda',
		  'cat' => 'Kategorie',
		  'chapter' => 'Kategoria',
		  'subchapter' => 'Podkategoria',
		  'orientation' => 'Orientacja',
		  'permutation' => 'Permutacja'
		  ),
		  
   'en' => array(
		  'main_site' => 'Main Site', 
		  'cat' => 'Categories',
		  'method' => 'Metoda',
		  'chapter' => 'Category',
		  'subchapter' => 'Subcategory',
		  'orientation' => 'Orientation',
		  'permutation' => 'Permutation'
		  )
);

?>