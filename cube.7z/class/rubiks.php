﻿<?

class Cube{

		var 
		
		
		$this->center_names[0]="F";
		$this->center_names[1]="B";
		$this->center_names[2]="R";
		$this->center_names[3]="L";
		$this->center_names[4]="U";
		$this->center_names[5]="D";

		$this->edge_names[0]="UF";
		$this->edge_names[1]="UR";
		$this->edge_names[2]="UB";
		$this->edge_names[3]="UL";
		$this->edge_names[4]="DF";
		$this->edge_names[5]="DR";
		$this->edge_names[6]="DB";
		$this->edge_names[7]="DL";
		$this->edge_names[8]="FR";
		$this->edge_names[9]="FL";
		$this->edge_names[10]="BR";
		$this->edge_names[11]="BL";
		$this->edge_names[12]="FU";
		$this->edge_names[13]="RU";
		$this->edge_names[14]="BU";
		$this->edge_names[15]="LU";
		$this->edge_names[16]="FD";
		$this->edge_names[17]="RD";
		$this->edge_names[18]="BD";
		$this->edge_names[19]="LD";
		$this->edge_names[20]="RF";
		$this->edge_names[21]="LF";
		$this->edge_names[22]="RB";
		$this->edge_names[23]="LB";

		$this->corner_names[0]="UFR";
		$this->corner_names[1]="UBR";
		$this->corner_names[2]="UBL";
		$this->corner_names[3]="UFL";
		$this->corner_names[4]="DFR";
		$this->corner_names[5]="DBR";
		$this->corner_names[6]="DBL";
		$this->corner_names[7]="DFL";
		
		$this->corner_names[8]="FRU";
		$this->corner_names[9]="RUB";
		$this->corner_names[10]="BLU";
		$this->corner_names[11]="LUF";
		$this->corner_names[12]="RDF";
		$this->corner_names[13]="BRD";
		$this->corner_names[14]="LDB";
		$this->corner_names[15]="FLD";
		
		$this->corner_names[16]="RUF";
		$this->corner_names[17]="BRU";
		$this->corner_names[18]="LUB";
		$this->corner_names[19]="FLU";
		$this->corner_names[20]="FRD";
		$this->corner_names[21]="RDB";
		$this->corner_names[22]="BLD";
		$this->corner_names[23]="LDF";

















}