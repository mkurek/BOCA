<?php
ob_start();
session_start();

include "includes/headers.php";
include "includes/hashes.php";
include "includes/reg_funcs.php";
include "includes/case_funcs.php";

for($i=1;$i<=count($hashes);$i++)
$hashes[$i] = trim($hashes[$i]);

if($_GET['act'] == 'send' && (checkCaptcha($_POST['captcha']) == '' || $_SESSION['login'] == 1) && trim($_POST['algs']) != '')
{

$errors = array();	
include "includes/add_algs_func.php";	

if($_POST['ifll'] == 'yes')	
$was = $_POST['was'];	
else $was = $_POST['was2'];																			
$cube = 3; 																	// 3x3x3
if($_POST['cube'] == '2x2x2') {$cube=2; $was='eg';}			// 2x2x2

//przetwarzanie $_POST['algs']

$algs = nl2br($_POST['algs']);
$algi = explode("<br />", $algs);
if(count($algi) < 2)
{
$algi = explode(',', $algs);
		if(count($algi) < 2)
		{$algi = explode("\n", $algs);
				if(count($algi < 2))
									$algi = explode(';', $algs);
		}
}



$ok = 0;
$bad = 0;
$bad_line = 0;

$if_ma = $_POST['if_ma'];
//$now = mktime(date("h"), date("i"), date("s"), date("m"), date("d"), date("Y"));
for($i=0;$i<count($algi);$i++)
{
$result = add_alg(stripslashes($algi[$i]), $cube, $was, $_SESSION['uid'], $if_ma);
if($result == 'bad_line') $bad_line++;
else if($result != '') {$errors[$bad][0] = $result; $errors[$bad][1] = stripslashes($algi[$i]); $bad++;}
else {$ok++; }

}
//$end = mktime(date("h"), date("i"), date("s"), date("m"), date("d"), date("Y"));


$smarty -> assign('ok', $ok);
$smarty -> assign('bad', $bad);
$smarty -> assign('bad_line', $bad_line);
$smarty -> assign('errors', $errors);
$smarty -> assign('what', 'show_raport');	
}

else{	
	
	$cap = checkCaptcha($_POST['captcha']);
	
	if(trim($_POST['algs']) == '' && $_GET['act'] == 'send') $smarty -> assign('error', 'empty_form');
	else if($cap != '' && $_GET['act'] == 'send' && $uid == 1) $smarty -> assign('error', 'bad_cap');

$smarty ->assign('what', 'show_form');	
}	


$smarty -> display('add_algs.tpl');

?>