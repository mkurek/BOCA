<?php
ob_start();
session_start();

include "includes/headers.php";

//ok

$smarty -> assign("or", $orientacja_upper);
$smarty -> assign("perm", $permutacja);



$smarty -> display('index.tpl');


?>