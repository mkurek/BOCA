<?php
ob_start();
session_start();

include "includes/headers.php";
include "includes/ucp_funcs.php";

if($_SESSION['login'] == 0)
{
	include "login.php";
}

else
{
	$uid = $_SESSION['uid'];
	$ch = $_GET['ch'];
	if($ch == '') $ch = 'main';
	
	$act = $_GET['act'];
	
	
	
	if($ch == 'img_cats')
	{
		$smarty -> assign('what', 'img_cats');
			
		$img_cats = array('cube', 'cube_oll', 'top_recognition', 'top_pll', 'top_oll', 'arrows');
		$smarty ->assign('img_cats', $img_cats);
		
		$tab = $imagecats;
		
		$query = "SELECT `cat_name`, `subcat_name`, `value` FROM `portal_users_imgcats` WHERE `user_id`=$uid";
		$result = query($query);	
		while($row = mysql_fetch_row($result))
		{
			$tab[$row[0]][$row[1]] = $row[2];
		}	
			

		// jeśli wysyłanie wyników
		if($act == 'send')
		{
			foreach($tab as $key=>$value)
			{
				 foreach($value as $key2=>$value2)
				       {
				       	$x = $key.'_'.$key2;
				       	
							 if($_POST[$x] == 'on') $wart = 1;
							 else $wart = 0;
							 							 	
				       	 	if($tab[$key][$key2] != $wart) 
				          	{
      	 							$tab[$key][$key2] = $wart;
				         			$query = "SELECT ID FROM `portal_users_imgcats` WHERE `cat_name`='$key' AND `subcat_name`='$key2' AND `user_id`=$uid;";
				         			$result = query($query);
				         			if(mysql_num_rows($result) == 0) $query = "INSERT INTO `portal_users_imgcats` VALUES(NULL, $uid, '$key', '$key2', $wart)";
				         			else $query = "UPDATE `portal_users_imgcats` SET `value`=$wart WHERE `user_id`=$uid AND `cat_name`='$key' AND `subcat_name`='$key2';";
				         	
				         	$result = query($query);
				         	
			         	 	}	 						  
						  }
				
				
				// sprawdzanie czy nie zostały odznaczone wszystkie opcje
				$check = is_no_empty($key);		  
						  
				if(!$check)
 		 		{
 		 					 		
		           if(isSet($tab[$key]['cube'])) $subcat = 'cube';
					  else $subcat = 'cube_oll';		  			  	  	 
		           		 	
		           $query = 	$query = "UPDATE `portal_users_imgcats` SET `value`=1 WHERE `user_id`=$uid AND `cat_name`='$key' AND `subcat_name`='$subcat';";	 	
		           $result = query($query);		 	
	           	  $tab[$key][$subcat] = 1;	 	
			   }		  				       
			
			}	 					 	
		
		$smarty -> assign("message", "img_cats_sended");		 					 	
	
		}	
	
		$smarty -> assign('imgcats', $tab);
	}
	
	
	
	
	else $smarty -> assign('what', 'nothing');
	
	
	$smarty -> display('ucp.tpl');	
}

?>