<?php
include "includes/headers.php";
?>

<head>
<title>Test</title>
<link rel="stylesheet" type="text/css" href="css/menu.css" />
<link rel="stylesheet" type="text/css" href="css/style2.css" />
</head>
<body>
<?php
/*
for($i=11000;$i<11126;$i++)
{
	$query = "SELECT `pre-moves`, `alg`, `post-moves`, `SID` FROM `portal_algs` WHERE ID=$i;";
	
	$result = query($query);
	$row = mysql_fetch_row($result);
	
	$alg = parse(stripslashes($row[0].$row[1].$row[2]));
	
	$jac = jacubize($alg);
	
	if($row[3] > 472 && $row[3] < 775) $jac = zbf2lize($jac);
	if($row[3] > 795 && $row[3] < 853) $jac = ollize($jac);
	if($row[3] > 852 && $row[3] < 979) $jac = pocketize($jac);
	
	$query = "SELECT `SID` FROM `portal_algs` WHERE `hash`='$jac' AND ID<979;";
	
	$result = query($query);
	if(mysql_num_rows($result) == 0) {$query = "DELETE FROM `portal_algs` WHERE ID=$i;"; echo $i.'-> delete!<br />';}
	else{
		  $row2 = mysql_fetch_row($result);
		  if($row2[0] != $row[3]) {$query = "UPDATE `portal_algs` SET SID=$row2[0], `hash`='$jac' WHERE ID=$i;"; echo $i.'-> zmiana!<br />';}
		  else continue;
	}
	
	$result3 = query($query);
	
}
echo '<br /><br />end!';

*/
$licz = 8465;
for($i=11127;$i<14503;$i++)
{
	$query = "SELECT `SID`, `pre-moves`, `alg`, `post-moves`, `hash` FROM `portal_algs` WHERE ID=$i";
	
	$result = query($query);
	
	$row = mysql_fetch_row($row);
	
	if($i< 11127) $query2 = "INSERT INTO `portal_algs` VALUES($licz, $row[0], '$row[1]', '$row[2]', '$row[3]', 2, '$row[4]');";
	else $query2 = "UPDATE `portal_algs` SET ID=$licz WHERE ID=$i;";
	
	//$result = query($query2);
	
	$licz++;
}

echo 'ok!';

?>
</body>
</html>