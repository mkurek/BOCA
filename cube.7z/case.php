<?php
ob_start();
session_start();

$max = 978;

$sid = $_GET['sid'];
$sid = explode(',', $sid);
if($sid[1] == '') $sid[1] = $sid[0];

$sid[0] = intval($sid[0]);
$sid[1] = intval($sid[1]);

include "includes/headers.php";
include "includes/case_funcs.php";
include "includes/add_algs_func.php";
include "includes/tree.php";

if(!isSet($sid[0]))$smarty -> assign('error', 'no_sid');
else if($sid[0] > $max) $smarty -> assign('error', 'no_sid');

else
{
$bet = get_bet($sid[0], $sid[1]);
$cube = new RubiksCube;

// kategoria

if(!isSet($_GET['cat'])) {$cat = 1; $cat_s = 'TH';}
if($_GET['cat'] != 'oh' && $_GET['cat'] != 'fm') {$cat = 1; $cat_s = 'TH';}
if($_GET['cat'] == 'oh') {$cat = 2; $cat_s = 'OH';}
if($_GET['cat'] == 'fm') {$cat = 3; $cat_s = 'FM';}

$smarty -> assign('cat', $cat_s);


// głosowanie OR wybór my_alg

if(isSet($_GET['act']) && isSet($_GET['id']))
{
		if($_GET['act'] == 'v1') vote($sid, intval($_GET['id']), $_SESSION['uid'], $cat, 1);
	
	if($_GET['act'] == 'v2') vote($sid, intval($_GET['id']), $_SESSION['uid'], $cat, -1);
	
	if($_GET['act'] == 'v3') my_alg($sid, intval($_GET['id']), $_SESSION['uid'], $cat);
}

//echo 'cat: '.$cat.'<br /><br />';
$i = 0;
$temp = array();
$algs = array();
// pobieranie algów

$maks = count($bet);

for($k=0;$k<$maks;$k++)
{
	$one = intval($bet[$k][0]);
	$two = intval($bet[$k][1]);
$query = "SELECT * FROM portal_algs WHERE SID BETWEEN $one AND $two;";

$result = query($query);



while($row = mysql_fetch_row($result))
{
	if($i == 0) $jac = $row[6];
	$query1 = "SELECT username FROM portal_users WHERE ID=$row[5];";
	
	$result2 = query($query1);
	$row2 = mysql_fetch_row($result2);

	$pre = $row[2];
	if($pre != '') $pre = '('.$pre.') ';
	
	$post = $row[4];
	if($post != '') $post = ' ('.$post.')';
	
	$alg = trim(stripslashes($pre.parse(stripslashes($row[3])).$post));
	
	$temp[$i][0] = intval($row[0]);													// id
	$temp[$i][1] = $alg;																	// alg
	$temp[$i][2] = moves($row[3], 'htm');											// moves htm
	$temp[$i][3] = moves($row[3], 'qtm');											// moves qtm
	$temp[$i][4] = moves($row[3], 'stm');											// moves stm
	$temp[$i][5] = moves($row[3], 'qstm');											// moves qstm
	$temp[$i][6] = $row2[0];															// user
	$i++;
}
}


 
 if(count($temp) > 100)
 {
	usort($temp,  "cmp_ros");
	$temp = array_slice($temp, 0, 99);
 }
 

 
 	$algs = votuj($temp, $sid, $_SESSION['uid'], $cat);


	// operacje na $jac
	if($sid[0] > 472 && $sid[1] < 775 && $sid[1] != $sid[0]) $jac = f2lize($jac);
	if($sid[0] < 473 && $sid[1] != $sid[0]) {$jac = collize($jac);}

	// przekazywanie czy user może głsować itd... 

	if($algs[0][9] == 'yes') $smarty -> assign('my_alg', 'yes'); 
	else $smarty -> assign('my_alg', 'no');
	
	if($_SESSION['uid'] == 1) $smarty -> assign('can_choose_my_alg', 'no');
	else $smarty -> assign('can_choose_my_alg', 'yes');
	
	if($_SESSION['rank'] == 103) $smarty -> assign('can_edit', 'yes');
	else $smarty->assign('can_edit', 'no');
	
	if($_SESSION['uid'] != 1) $smarty-> assign('can_vote', 'yes');
	else $smarty-> assign('can_vote', 'no');
	
// komentarze
/*
$query = "SELECT * FROM portal_comments WHERE SID=$sid";

if(!$result = mysql_query($query)){
		echo('Nieprawidłowe zapytanie2');
		mysql_close();
		exit;
		}
		
if(mysql_num_rows($result) != 0)		
{
	$com = array();
	
 while($row = mysql_fetch_row($result))
 {
 	$com[$i][0] = $row[0];						// ID
 	$com[$i][1] = $row[1];						// userID
 	$com[$i][2] = $row[3];						// content
 	$com[$i][3] = $row[4];						// date
	 } 


$smarty -> assign('comments', $com);
$smarty -> assign('comments_isSet', 'yes');
}
else $smarty -> assign('comments_isSet', 'no');


*/


// kategoria && imgcats
$cat = get_cat($sid[0], $sid[1]);
$images = get_imgcats($cat, $_SESSION['uid']);
if($cat == 'ortega_cp' || $cat == 'ortega_co') $cat = 'ortega';

$max = count($images);
if($max>4) {$max = ceil($max/2); $smarty -> assign('if_next', true);}
$smarty -> assign('max', $max);

$name = licz_sid($sid);

if(isSet($_SESSION['method']) && $name< 473) $cat_name = $_SESSION['method'];
else $cat_name = get_cat_name($name);

//echo '$_SESSION[\'method\']: '.$_SESSION['method'];


//poprzedni, nastepny
$prev = get_prev($sid, $cat_name);
$next = get_next($sid, $cat_name);
$smarty -> assign('prev', $prev);
$smarty -> assign('next', $next);


$smarty -> assign('images', $images);
$smarty -> assign('cat_name', $cat);


// elementy potrzebne do drzewka

$tab = tree_gen($name, $cat_name, strtolower($cat_s));
$smarty -> assign('tree', $tab[0]);
$smarty -> assign('chapter', $tab[2]);												// chapter
$smarty -> assign('subchapter', $tab[3]);										// subchapter
$smarty -> assign('orientation', $tab[4]);										// orientacja
$smarty -> assign('permutation', $tab[5]);										// permutacja
$smarty -> assign('method', $tab[1]);													// metoda

// jeśli pll -> do menu
if($tab[2] == 'pll')
{
$smarty -> assign('pll_titles', $pll_titles);
$smarty -> assign('pll', ($name-774));
}

$smarty -> assign('name', $name);							// liczba
$smarty -> assign('sid', $sid);								// tablica

$smarty -> assign('algs', $algs);
$smarty -> assign('cat_s', strtolower($cat_s));
$smarty -> assign('jac', $jac);
$smarty -> assign('site_title', 'Case '.$name.' ('.$cat_s.')');

}

/*
$tab = $smarty -> get_template_vars();


foreach($tab as $key=>$value)
{
	echo $key.' => ';
var_dump($value);
echo '<br />';
}

*/
$smarty -> display('case.tpl');
?>