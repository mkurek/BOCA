<?php
ob_start();
session_start();

include "includes/headers.php";
include "includes/cat_funcs.php";

$step = 2;
$img_cat_different = false;

$m = $_GET['m'];
if($m == '') $m = 'cats';
$method = $m;
$smarty ->assign('method', $m);


if($_GET['mode'] == 'print') $mode = 'print';
$smarty -> assign('mode', $mode);


if(isSet($_SESSION['uid'])) $uid = $_SESSION['uid'];
else $uid=1;

if(!isSet($_GET['m'])) include("includes/cats/cats.php");

else if($m == 'fridrich') include("includes/cats/fridrich.php");

else if($m == 'coll') include("includes/cats/coll.php");

else if($m == 'zb') include("includes/cats/zb.php");

else if($m == 'eg') include("includes/cats/eg.php");

else if($m == 'zz') include ("includes/cats/zz.php");

else if($m == 'ortega') include("includes/cats/ortega.php");

else include("includes/cats/cats.php");

include "includes/tree.php";

$smarty -> assign('img_main', $img_main);  											// czy obrazek "glowny"
$smarty -> assign('top_img_cat', $top_img_cat);										// kategoria gl. obrazka
$smarty -> assign('top_img_cats', $top_img_cats);									// podkategorie

$smarty -> assign('what_in_section', $what_in_section);							// co się zmienia w section
$smarty -> assign('in_section', $in_section);										// co do przelecenia w section	
$smarty -> assign('title', $title);														// tytul
$smarty -> assign('file', $file);														// plik ktory ma byc w linku ({cat, file})


if($mode == 'print')
	{
		$smarty -> assign('file', 'cat');
		$imgcats = get_imgcats($get_imgcats_id, $uid); 
		if(count($imgcats) > 3) $msarty -> assign('column', 1);
		else if(count($imgcats) > 1 && count($imgcats) < 4) $smarty -> assign('column', 2);
		else $smarty -> assign('column', 3);
		$smarty -> assign('colspan', count($imgcats));			
		$smarty -> assign('title_big', $title_big);									// tytuly glowne
		$smarty -> assign('title_little', $title_little);							// tytuly posrednie
	}

$smarty -> assign('image_cat', $image_cat);											// glowna kategoria obrazkow
$smarty -> assign('img_cats', $imgcats);											   // podkategorie obrazkow
$smarty -> assign('img_cat_different', $img_cat_different);						// czy obrazki beda rozne

$smarty -> assign('situations_id', $sid);												// sid_array
$smarty -> assign('algs', $algs);														// algi
$smarty -> assign('size', count($algs));												// rozmiar algow (?)

$smarty -> assign('chapter', $chapter);												// chapter
$smarty -> assign('subchapter', $subchapter);										// subchapter
$smarty -> assign('orientation', $orientation);										// orientacja
$smarty -> assign('permutation', $permutation);										// permutacja
$smarty -> assign('method', $method);												// metoda

if($method == 'zz' && $file == 'case')
{
 	$_SESSION['method'] = 'zz'.$chapter;	
}
else {if(isSet($_SESSION['method'])) unset($_SESSION['method']);}


$smarty -> assign('step', $step);														// krok w petlach
$smarty -> assign('tree', $tree);


if($chapter == 'pll')
$smarty -> assign('pll_titles', $pll_titles);



// site_title

if($method != 'zb')$site_title = strtoupper($method);
else if($method == 'zb' && $chapter != 'zbll' && $chapter != 'zbf2l')$site_title = strtoupper($method);
else $site_title = strtoupper($chapter);
//var_dump($chapter);
if($chapter != '' && $chapter != 'zb' && $chapter != 'zbf2l') $site_title .= ' -> '.strtoupper($chapter);
if(is_int($subchapter)) $site_title .= ' -> OLL '.$orient[$subchapter];
if($orientation != '') $site_title .= ' -> OLL '.$orient[$orientation];
if($permutation != '') $site_title .= '.'.strtolower($perm[$permutation]);

$smarty -> assign('site_title', $site_title);

if($mode == 'print' && isSet($_GET['m'])) $smarty -> display('print.tpl');
else $smarty -> display('cat_new.tpl');

?>