<?php
$cats = array('fridrich', 'coll', 'zb', 'zz', 'eg', 'ortega');

$smarty -> assign ('cats', $cats);
$smarty -> assign('level', 'method_choose');
?>