<?php

include "includes/add_algs_func.php";

?>