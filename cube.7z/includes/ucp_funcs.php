<?php
include 'arrays.php';

function is_no_empty($key)
{
	global $imagecats;
	
	$check = false;
			 
			 foreach($imagecats[$key] as $key2=>$value)
 			{
 				$x = $key.'_'.$key2; 			
 				if($_POST[$x] == 'on' || $_POST[$x] == 1) {$check = true;} 
	      }

return $check;
}






?>