<?php

include "configs/lang.php";

$lang = 'pl';
if(isSet($_GET['l'])) $lang = $_GET['l'];

$tree = array("<a href='index.php?l=$lang&cat=$cat_s'>{$text[$lang]['main_site']}</a>", "<a href='cat.php?l=$lang&cat=$cat_s'>{$text[$lang]['cat']}</a>");


if($method != '')
$tree[] = "<a href='cat.php?l=$lang&cat=$cat_s&m=$method'>".$text[$lang]['method'].": ".strtoupper($method).'</a>';

if($chapter != '')
{
	$tree[] = "<a href='cat.php?l=$lang&cat=$cat_s&m=$method&ch=$chapter'>".$text[$lang]['chapter'].": ".strtoupper($chapter).'</a>';
}

if($subchapter != '' )
{
	if($chapter != 'zbf2l')
	{
	if(is_int($subchapter)) $temp = 'OLL '.$orient[$subchapter];
	else $temp = strtoupper($subchapter);
	$tree[] = " <a href='cat.php?l=$lang&cat=$cat_s&m=$method&ch=$chapter&sch=$subchapter'>".$text[$lang]['subchapter'].": ".$temp.'</a>';	
	}
	
	else
	{
		$tree[] = " <a href='cat.php?l=$lang&cat=$cat_s&m=$method&ch=$chapter&sch=$subchapter'>".$text[$lang]['subchapter'].": ".$subchapter.'</a>';		
	}


}

if($orientation != '')
{
	if($subchapter == '') $tree2 = "<a href='cat.php?l=$lang&cat=$cat_s&m=$method&ch=$chapter&o=$orientation'>";

	else $tree2 = "<a href='cat.php?l=$lang&cat=$cat_s&m=$method&ch=$chapter&sch=$subchapter&o=$orientation'>";
	
	$tree2 .= $text[$lang]['orientation'].": ".$orient[$orientation].'</a>';	
	
	$tree[] = $tree2;
}

if($permutation != '')
{
	if($orientation == 7) $perm = $permh;
	
	if($subchapter == '') $tree2 = "<a href='cat.php?l=$lang&cat=$cat_s&m=$method&ch=$chapter&o=$orientation&p=$permutation'>";
	else $tree2 = "<a href='cat.php?l=$lang&cat=$cat_s&m=$method&ch=$chapter&sch=$subchapter&o=$orientation&p=$permutation'>";
	
	$tree2 .= $text[$lang]['permutation'].": ".strtolower($perm[$permutation]).'</a>';	
	
	$tree[] = $tree2;
}

if($method == 'fridrich' && $chapter == 'pll' && $if_case == true)
{
	$tree2 = 'PLL '.$pll_titles[$pll-1];
	$tree[] = "<a href='case.php?l=$lang&cat=$cat_s&sid=$sid'>".$tree2.'</a>';
}


?>