<?php

include "includes/add_algs_func.php";
include "includes/case_funcs.php";

function get_algs($min, $max, $cat, $uid)
{
$algs = array();

for($i=$min;$i<=$max;$i++)
{
	$algs[] = get_best_alg($i, $cat, $uid);
}

return $algs;
}


function get_alg($sid, $cat, $uid)
{
 $alg = get_best_alg($sid, $cat, $uid);
 return $alg;
}

function get_best_alg($sid, $cat, $uid=1)
{
	$temp = licz_sid($sid);
	if(is_array($sid)) $bet = get_bet($sid[0], $sid[1]);
	
	// sprawdzanie czy user ma swój alg
   if($uid != 1)
   {
	 		  $query = "SELECT `alg_id` FROM `portal_users_algs` WHERE `sid`=$temp AND `user_id`=$uid AND `cat`='$cat';";
			  $result = query($query);
			  if(mysql_num_rows($result) != 0)
			  {
			      $row = mysql_fetch_row($result);
					$best_alg_id = $row[0];
			  }
   }
	
	
	// jeśli user nie ma swojego alga -> sprawdzanie głosów
	if($best_alg_id == '')
	{
		$query = "SELECT `alg_id` FROM `portal_votes` WHERE sid=$temp AND cat='$cat' ORDER BY SUM(vote) DESC LIMIT 1;";
		$result = query($query);
		if(mysql_num_rows($result) != 0)
  		{
				$row = mysql_fetch_row($result);
				$best_alg_id = $row[0];
      }
	}
$k=0;
	  //var_dump($bet);
	  //echo '<br /><br />';

	// jeśli best_alg_id nadal == 0
	if($best_alg_id == '') 
	{
		$tab = array();	
		if(is_array($sid))
		{
			$maks = count($bet);

			for($z=0;$z<$maks;$z++)
			{
	            $one = intval($bet[$z][0]);
			 		$two = intval($bet[$z][1]);		
					$query = "SELECT `pre-moves`, `alg`, `post-moves` FROM portal_algs WHERE SID BETWEEN $one AND $two;";
					
					$result = query($query);
					while($row = mysql_fetch_row($result))
      			{
      				$pre = $row[0];
						if($pre != '') $pre = '('.$pre.')';
						$post = $row[2];
            		if($post != '') $post = '('.$post.')'; 
				    	
	 			  		$tab[$k][0] = stripslashes($pre.' '.$row[1].' '.$post);
						$tab[$k][1] = moves($row[0].$row[1].$row[2], 'htm');
      			 	$k++;
				   }
		   }
		}
	   
		else 
		{		
		   $query = "SELECT `pre-moves`, `alg`, `post-moves` FROM portal_algs WHERE SID=$sid;";
		
			$result = query($query);
			while($row = mysql_fetch_row($result))
      	{
      		$pre = $row[0];
				if($pre != '') $pre = '('.parse($pre).')';
				$post = $row[2];
            if($post != '') $post = '('.parse($post).')'; 
				    	
	 			  $tab[$k][0] = stripslashes($pre.' '.parse($row[1]).' '.$post);
      		  $tab[$k][1] = moves($row[0].$row[1].$row[2], 'htm');
      		  $k++;
	      }
 		}
   
		$tab = sortuj_ros($tab, 1);
		$best_alg = trim($tab[0][0]);
	
	}
    else
	 {
     	 $query = "SELECT `pre-moves`, `alg`, `post-moves` FROM `portal_algs` WHERE id=$best_alg_id"; 	
    	 $result = query($query);
    	 $row = mysql_fetch_row($result);
    	 $pre = $row[0];
		 if($pre != '') $pre = '('.$pre.')';
		 $post = $row[2];
       if($post != '') $post = '('.$post.')'; 
       
	    $best_alg = trim((stripslashes($pre.' '.parse($row[1]).' '.$post)));
	 }

return $best_alg;
}

?>