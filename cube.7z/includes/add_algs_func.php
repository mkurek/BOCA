<?php

include 'getsituation.php';

// SZUKANIE ZLYCH SYMBOLI W ALGU                      
function allowed($alg)
{
	if(preg_match("/[^ 2RLFBDUXYZMSE'rlfbduxyzwsa]/", $alg)) return false;
	else return true;	
}


//PARSOWANIE ALGORYTMU
function parse($input) {
		$count=-1;
		$char=substr($input,0,1);
		$input=substr($input,1);
		$moves = '';
		while($char)
		{
			if ($char==" " || $char=="(" || $char==")")
			{
				$char=substr($input,0,1);
				$input=substr($input,1);
				continue;
			}
			if ($char=="'" || $char=="2" || $char=="s" || $char=="a")
			{
				$moves[$count].=$char;	
			}
			else
			{
				$count++;
//				if ($moves[$count]!="")
//					$count++;
				$moves[$count]=$char;
			}
			$char=substr($input,0,1);
			$input=substr($input,1);
		}
		if($moves != '') return implode(' ', $moves);
		else return '';
}


// SZUKANIE RUCHOW PRZED
function find_pre($alg, $was, $poprz='')
{
	$pre = '';
	$ktory = count($poprz);	
   $ile = 0;
	if($was != 'eg')
   {
	if($ktory == 0 || ($poprz[0] == 'y' && $ktory == 1)) $pattern = '/^[UXYZxyz]$/D';
	else $pattern = '/^[XYZxyz]$/D';
	}
	
	else{
	if($ktory < 2 && $poprz[0] != 'x' && $poprz[0] != 'z' && $poprz[1] != 'x' && $poprz[1] != 'z') $pattern = '/^[UDXYZxyz]$/D';
	else $pattern = '/^[XYZxyz]$/D';	
	}
	
	if(preg_match($pattern, substr($alg, 0, 1)))
 	{
 		$pocz = substr($alg, 0, 1); 	
 		if($pocz == 'U' && $was != 'zbf2l' && $was !='eg') {$pocz = 'y';}
 		
		 if(substr($alg, 1, 1) == "'") {$pre = $pocz."'"; $ile = 2;}
 		
		 else if(substr($alg, 1, 1) == '2') {$pre = $pocz.'2'; $ile = 2;}
 		
		 else {$pre = $pocz; $ile = 1;}	 
   }

$alg = trim(substr_replace($alg, '', 0, $ile));

$tab = array($pre, $alg);

return $tab;	
} 


// SZUKANIE RUCHOW PO
function find_post($alg, $cat, $poprz)
{
	$post = '';
	$size = count($poprz);
	
	if($cat == 'eg')
   {
	     if($size == 0) $pattern = '/[UDXYZxyz]/';
		  
		  else if($size == 1) 
 		  { 		  
		  		 if($poprz[0] == 'U' || $poprz[0]== 'y' || $poprz[0]=='Y' || $poprz[0]=='D') $pattern = '/[UDXYZxyz]/';	 	
		  		 else $pattern = '/[XYZxyz]/';	
        }
        
		  else if($size == 2)
        {
        		 if(($poprz[0] == 'U' || $poprz[0]== 'y' || $poprz[0]=='Y') && ($poprz[1] == 'U' || $poprz[1]== 'y' || $poprz[1]=='Y' || $poprz[0]=='D' || $poprz[1]=='D')) $pattern = '/[UDXYZxyz]/';	 	
		  		 else $pattern = '/[XYZxyz]/';
		  }
		  
		  else $pattern = '/[XYZxyz]/';
	}
	
	else
	{
		  if($size == 0) $pattern = '/[UXYZxyz]/';
		  
		  else if($size == 1) 
 		  {
		  		 if($poprz[0] == 'U' || $poprz[0]== 'y' || $poprz[0]=='Y') $pattern = '/[UXYZxyz]/';	 	
		  		 else $pattern = '/[XYZxyz]/';	
        }
        
		  else if($size == 2)
        {
        		 if(($poprz[0] == 'U' || $poprz[0]== 'y' || $poprz[0]=='Y') && ($poprz[1] == 'U' || $poprz[1]== 'y' || $poprz[1]=='Y')) $pattern = '/[UXYZxyz]/';	 	
		  		 else $pattern = '/[XYZxyz]/';
		  }
		  
		  else $pattern = '/[XYZxyz]/';
	}
	
	if(preg_match($pattern, substr($alg, -1, 1)))
 	{
 		 $post = substr($alg, -1, 1); 	
	 	 $alg = substr_replace($alg, '', -1);
	 }
	 
	 else if(preg_match("/['2]/", substr($alg, -1, 1)) && preg_match($pattern, substr($alg, -2, 1)))
	 {
	 	$post = substr($alg, -2, 2);
	 	$alg = substr_replace($alg, '', -2);
	 }
	 
	 $tab = array($alg, $post);
	 
return $tab;	
} 




// ALG PRZEKAZYWANY DO FUNKCJI -> WYCHODZI TABLICA (PRE, ALG, POST)
function search_pre_post($alg, $cat)
{
	$pre = '';
$k = 0;
$temp = array(' ','');
$poprz = array();
while($temp[0] != '' && $k<4)
{
	$temp = find_pre(trim($alg), $cat, $poprz);
	$pre .= ' '.$temp[0];
	$poprz[] = substr($temp[0], 0, 1);
	$alg = $temp[1];
	$k++;
}

$temp = array('', ' ');
$post = '';
$k = 0;
$poprz = array();
while($temp[1] != '' && $k<4)
{
	$temp = find_post(trim($alg), $cat, $poprz);
	$post = $temp[1].' '.$post;
	$poprz[] = substr($temp[1], 0, 1);
	$alg = $temp[0];
	$k++;	
}
	
	return array($pre, $alg, $post);
	
}



// GENEROWANIE OBROTOW "PO" NA PODSTAWIE ROGU DFL
function find_post2($jac)
{
	//$post2 = array(array("y x", "y2 x", "y' x", "x",  "y x'", "y2 x'", "y' x'", "x'",  "y2", "x2", "z2", ""), array("y2 z'", "y' z'", "z'", "y z'",  "z' y2", "x' y'", "z", "x y",  "x2 y'", "y", "y'", "z2 y'"));  		// kraw BL
	
	$post2 = array(array("z2", "y z2", "x2", "y' z2", "y", "y2", "y'", ""), array("x' y", "z y2", "x y'", "z'", "z", "x y", "z' y2", "x' y'"), array("z y", "x y2", "z' y'", "x'", "x' y2", "z y'", "x", "z' y"));
	
	$temp = explode(' ', $jac);
	$i=0;
	$k=0;
	$prawda = true;
	$post = '';
	while($temp[$i] != '!!' && $i<12) {$i++;}
	$z = $i;
	$i++;
	while($temp[$i] != '!!' && $i<19)
	{
		if($temp[$i] == 'DFL') {$k = 0; $prawda = false; break;}
		if($temp[$i] == '-DFL') {$k = 1; $prawda = false; break;}
		if($temp[$i] == '+DFL') {$k = 2; $prawda = false; break;}
		$i++;
	}
	
	if($i == 19)
	{
		if($temp[19] == '!') $k = 0;
		else if($temp[19] == '-!') $k = 1;
		else $k= 2;	
	}

	if(!$prawda) 
	{
      $post = $post2[$k][$i-$z];
	}
	//echo '$post: '.$post.'<br />';
	
	return $post;
}



// sytuacja JAC
function jacubize($alg, $mode='reverse')
{
	$cube = new RubiksCube;
$temp = $cube -> getElemsName($alg, $mode);

$jac = '';

foreach($temp as $val)
	$jac .= $val.' ';	
	
return $jac;
}



// przetworzenie na Pocket Cube
function pocketize($alg)
{
	$temp = explode(' ', trim($alg));
$k=0;
while($k<12)
{
if($temp[$k] == '!!') {break;}	
$k++;	
}	
if($k==12) $k--;
$alg = '@?? ';

for($i=$k+1;$i<count($temp);$i++)
$alg .= $temp[$i].' ';
	
	return trim($alg);
}


function collize($jac)
{
	$temp = explode(' ', trim($jac));
	for($i=0;$i<4;$i++)
      $temp[$i] = '?';
	
	return trim(implode(' ', $temp));
}


// przetwarzanie na f2l
function f2lize($jac)
{
$temp = explode(' ', $jac);

// przetwarzanie kraw
for($i=0;$i<4;$i++)
{
	if(substr($temp[$i], 0, 1) != 'F' && substr($temp[$i], 1, 1) != 'F')$temp[$i] = '@?';
}	
if($temp[4] != '!!' && $temp[8] != '-!')
{
	$temp[8] = '@?';
}

if($temp[4] == '!!') $pocz = 5;
else $pocz = 10;
	
//przetwarzanie rogow
for($i=$pocz;$i<$pocz+4;$i++){
	if($temp[$i] != 'DRF' && $temp[$i] != '-DRF' && $temp[$i] != '+DRF') $temp[$i] = '@?';
}	
if($temp[$pocz+4] != '!' && $temp[$pocz+4] != '-!' && $temp[$pocz+4] != '+!' && $temp[$pocz+4] != '!!') $temp[$pocz+4] = '@?';
	
	$jac = implode(' ', $temp);

return $jac;
}


// przetworzenie na oll
function ollize($jac)
{	
// krawedzie
$temp = explode(' ', $jac);
$v=0;
$pocz = 4;
while($v<=3)
{
	if($temp[$v] == '-!') $temp[$v] = '-?';
	if($temp[$v] == '!') $temp[$v] = '?';
	if($temp[$v] == 'UR' || $temp[$v] == 'UB' || $temp[$v] == 'UF' || $temp[$v] == 'UL') $temp[$v] = '?';
	if($temp[$v] == '-UR' || $temp[$v] == '-UB' || $temp[$v] == '-UF' || $temp[$v] == '-UL') $temp[$v] = '-?';	
	if($temp[$v] == '!!') {$pocz = $v; break;}
	
	$v++;
}	

// rogi
$v=$pocz+1;
while($v < $pocz+5)
{
	if($temp[$v] == '-!') $temp[$v] = '-?';
	if($temp[$v] == '+!') $temp[$v] = '+?';
	if($temp[$v] == '!') $temp[$v] = '?';
	if($temp[$v] == '-ULF' || $temp[$v] == '-UFR' || $temp[$v] == '-URB' || $temp[$v] == '-UBL') $temp[$v] = '-?';
	if($temp[$v] == '+ULF' || $temp[$v] == '+UFR' || $temp[$v] == '+URB' || $temp[$v] == '+UBL') $temp[$v] = '+?';
	if($temp[$v] == 'ULF' || $temp[$v] == 'UFR' || $temp[$v] == 'URB' || $temp[$v] == 'UBL') $temp[$v] = '?';
	if($temp[$v] == '!!') {break;}
	$v++;
}	

$jac = implode(' ', $temp);

return $jac;
}



// przetwarzanie na zbf2l
function zbf2lize($jac)
{
$temp = explode(' ', $jac);

// przetwarzanie kraw
for($i=0;$i<4;$i++)
{
	if($temp[$i] != 'FR' && $temp[$i] != '-FR')
	{
			if(substr($temp[$i], 0, 1) == '-') $temp[$i] = '-?';
			else $temp[$i] = '?';
	}	
}

if($temp[4] != '!!' && $temp[8] != '-!')
{
	if(substr($temp[8], 0, 1) == '-')$temp[8] = '-?';
	else $temp[8] = '?';	
}

if($temp[4] == '!!') $pocz = 5;
else $pocz = 10;
	
//przetwarzanie rogow
for($i=$pocz;$i<$pocz+4;$i++){
	if($temp[$i] != 'DRF' && $temp[$i] != '-DRF' && $temp[$i] != '+DRF') $temp[$i] = '@?';
}	
if($temp[$pocz+4] != '!' && $temp[$pocz+4] != '-!' && $temp[$pocz+4] != '+!' && $temp[$pocz+4] != '!!') $temp[$pocz+4] = '@?';
	
	$jac = implode(' ', $temp);

return $jac;
}


// kiedy ruchy sie zosza zastepowane sa obrotem
function merge_moves($postm)
{
	$postm = trim($postm);
	if($postm == "UD'") $postm = "y";
	else if($postm == "U'D") $postm = "y'";
	else if($postm == "U2D2") $postm = 'y2';
	
	else $postm = $postm;

	return $postm;
}



// usuwanie smieci
function obrobka($alg)
{
$alg = trim($alg);
$alg = str_replace("(", "", $alg);
$alg = str_replace(")", "", $alg);
$alg = str_replace("[", "", $alg);
$alg = str_replace("]", "", $alg);
$alg = str_replace(".", "", $alg);
$alg = str_replace("Y", "y", $alg);
$alg = str_replace("X", "x", $alg);
$alg = str_replace("Z", "z", $alg);
$alg = str_replace("’", "'", $alg);
// sprawdzanie, czy jest koncowka z JAC z liczba ruchow

if(substr($alg, -1) == 's' && is_int(intval(substr($alg, -2, 1))) == true)
{
	$start = stripos($alg, "q") - 2;
   $alg = trim(substr_replace($alg, ' ', $start));
}

for($i = 0;$i<strlen($alg);$i++)
if(substr($alg, $i, 2) == "2'" || substr($alg, $i, 2) == "'2") $alg = trim(substr_replace($alg, '2', $i, 2));

for($i = 0;$i<strlen($alg);$i++)
if(substr($alg, $i, 2) == "w'" || substr($alg, $i, 2) == "'w") $alg = trim(substr_replace($alg, strtolower(substr($alg, ($i-1),1))."'", ($i-1), 3));

for($i = 0;$i<strlen($alg);$i++)
if(substr($alg, $i, 2) == "w2" || substr($alg, $i, 2) == "2w") $alg = trim(substr_replace($alg, strtolower(substr($alg, ($i-1),1))."2", ($i-1), 3));

for($i = 0;$i<strlen($alg);$i++)
if(substr($alg, $i, 1) == "w" || substr($alg, $i, 1) == "w") $alg = trim(substr_replace($alg, strtolower(substr($alg, ($i-1),1)), ($i-1), 2));

return trim($alg);	
}


// sprawdzenie duplikatu
function cloned($alg, $cat)
{
	$ile = 1;
	
	//echo '$cat: '.$cat.'<br />';
	
	if($cat == 'eg'){$min = 853; $max=978;}
	else if($cat == 'oll'){$min=796;$max=852;}
	else if($cat == 'zbf2l'){$min=473;$max=774;}
	else if($cat == 'zbll'){$min=1;$max=472;$ile=2;}
	$temp = $ile;
		
	for($i=0;$i<$ile;$i++)
	{//echo '$min: '.$min.'<br />$max: '.$max.'<br />';
			$query = "SELECT ID FROM portal_algs WHERE alg='$alg' AND SID BETWEEN $min AND $max";
			  $result = query($query);
			  $row = mysql_fetch_row($result);
			  //echo 'mysql_num_rows() = '.mysql_num_rows($result).'<br />';
			  if(mysql_num_rows($result) == 0 && $temp == 1) return true;
			  else if(mysql_num_rows($result) != 0) return $row[0];
			  else
			  {
			  	$min = 775;
			  	$max = 795;
			  	$temp = 1;
			  }
			  
	}
	
	return true;
}


//sprawdzenie istnienia SID dla danego $jac -> dodanie algu
function insert($pre, $alg, $post, $suid, $jac, $if_ma, $cat='pll')
{
 global $hashes;
    $i=0;
	 if($cat == 'eg') $i=852;
	 $falsz = true;
	 $jac = trim($jac);
	 while($falsz) 
	 {
	 	$i++;	 
	 	if(trim($hashes[$i]) == $jac) $falsz = false;
	 	if($i>978) $falsz = false;	 		
	 }
	 
	//echo $pre.' '.$alg.' '.$post;
	//echo '<br />'.$jac.'<br /><br />';

 	 if($i<979)
 	 { 
			$pre = addslashes(parse(trim(merge_moves($pre))));
			$alg = addslashes(trim($alg));
			$post = addslashes(parse(trim(merge_moves($post))));	
				 
			$query = "INSERT INTO portal_algs VALUES (NULL, $i, '$pre', '$alg', '$post', $suid, '$jac');";
	
	  		$result = query($query); 
	  		
	  		if($if_ma == 'on')
	  		{
			$query = "SELECT ID FROM `portal_algs` WHERE alg='$alg' AND SID=$i;";
			$result = query($query);
			$row = mysql_fetch_row($result);
			
			$id = $row[0];  
			  
			$result = my_alg($i, $id, $suid, 1);  
		   } 
			  return '';
	}
	
	else return 'no sid';
	
	return false;
}


function jac_hash($alg)
{
	if(preg_match("/[^ !~0134567+-]/", $alg)) return false;
	return true;
}


//-------------------------------------------------------
// main function
//-------------------------------------------------------

function add_alg($alg, $size, $cat, $suid, $if_ma)
{
if($suid == 1) $suid =2;
/*
$pre_tab = array( array("", "z", "z'", "z2"), array("", "x", "x'", "x2"), array("", "y", "y'", "y2"), array("", "U", "U'", "U2"), array("", "D", "D'", "D2"));
$post_tab = array("", "U", "U'", "U2");
$post_d_tab = array("", "D", "D'", "D2");
*/

$pre_tab = array("", "y", "y'", "y2", "x", "x'", "x2", "z", "z'", "z2", "y' x", "y2 x", "y x", "y' x'", "y x'", "y2 x'", "x' y", "x y", "x2 y", "y2 z", "y2 z'", "y' z'", "y' z", "y' z2");
//echo count($pre_tab);
$post_tab = array(array("", "U", "U'", "U2"), array("", "D", "D'", "D2"));

$pre_tab2 = $post_tab;


if(trim($alg) == '') return 'bad_line';						 
$alg = parse(obrobka($alg));

if(!allowed($alg)) 
{	
	if(!jac_hash($alg)) return 'bad_line';
	else return 'bad_symbols'; 
}

//echo $cat.'<br />';

// usuwanie z algu pre i post
$tab = search_pre_post($alg, $cat);
$pre = parse(trim($tab[0]));
$alg = parse(trim($tab[1]));
$post = parse(trim($tab[2]));


$p=0;
//echo 'wnetrze add_alg: <br />$pre: '.$pre.'<br />$alg: '.$alg.'<br />$post: '.$post.'<br /><br />';
$klon = cloned(addslashes($alg), $cat);
if($klon=== true)
{	
	
$jac = jacubize($pre.$alg.$post);
if($cat == 'oll')	$jac = ollize($jac);	
else if($cat == 'zbf2l') $jac = zbf2lize($jac);
if($size == 2 || $cat == 'eg') $jac = pocketize($jac);

$res = insert(parse($pre), parse($alg), parse($post), $suid, trim($jac), $if_ma);

if($res == '') return '';	
/*	
for($h=0;$h<count($pre_tab[0]);$h++)															// pre{"", z, z', z2}
{
   for($j=0;$j<count($pre_tab[1]);$j++)														// pre{"", x, x', x2}
   {
   	for($k=0;$k<count($pre_tab[2]);$k++)													// pre{"", y, y', y2}
   	{
   		for($l=0;$l<count($pre_tab[3]);$l++)												// pre{"", U, U', U2}
   		{
				if($cat == 'eg')																			
		      {
   			    for($l2=0;$l2<count($pre_tab[4]);$l2++)											// pre{"", D, D', D2}
				  	 {  			    		
 							$prem = trim($pre_tab[3][$l].$pre_tab[4][$l2].$pre_tab[0][$h].$pre_tab[1][$j].$pre_tab[2][$k]);   		
   			
				 			for($m=0;$m<count($post_tab);$m++)												// post{"", U, U', U2}
				 			{   		
								$jac = jacubize($prem.$alg.$post_tab[$m], 'normal');				
		 		   			//echo '$jac1: '.$jac.'<br />$alg1: '.parse($prem.$alg).'<br />';
								$postm2 = find_post2($jac, $cat);
													
	            
 							   $ile=4;
								for($n=0;$n<$ile;$n++)														// post2{"", U, U', U2}
								{		
		   			         for($o=0;$o<$ile;$o++)													// post_d{"", D, D', D2}
									{	
										if(trim($postm2) == '') $postm = $post_tab[$n].$post_d_tab[$o];																
  		                  		else $postm = $post_tab[$m].$postm2.$post_tab[$n].$post_d_tab[$o];
  			  					 		$jac = pocketize(jacubize($prem.$alg.$postm));
								 
								 		//echo '<br />$p: '.$p.'<br />$alg2: '.parse($prem.$alg.$postm).'<br />$jac2: '.$jac.'<br />';
     	  						 		$res = insert(parse($prem), parse($alg), parse($postm), $suid, trim($jac)); 			
 	  				 		//if(is_int($res) && $res != 0) return array($res, $prem, $alg, $postm, $jac, jacubize($prem.$alg.$postm));
 				 					   if($res == '') return $p;
	 	   	  				 		else $p++;	 
		         			   }
               		  }
	                  }
		          }
		      
	         }
				   
				else
	   		{	
		   		 $prem = trim($pre_tab[3][$l].$pre_tab[0][$h].$pre_tab[1][$j].$pre_tab[2][$k]);   		
   			
				 	 for($m=0;$m<count($post_tab);$m++)												// post{"", U, U', U2}
				 	 {   		
			 			 $jac = jacubize($prem.$alg.$post_tab[$m], 'normal');				
		 		   	 //echo '$jac1: '.$jac.'<br />$alg1: '.parse($prem.$alg).'<br />';
						 $postm2 = find_post2($jac, $cat);
													 					
				    	 if(trim($postm2) == '') $ile = 1;
						 else $ile=4;
							
						 $ile=4;
							
						 for($n=0;$n<$ile;$n++)															// post2{"", U, U', U2}
						 {						
							   if(trim($postm2) == '') $postm = $post_tab[$m];
					  			else $postm = $post_tab[$m].$postm2.$post_tab[$n];

								$jac = jacubize($prem.$alg.$postm);
								if($cat == 'oll')	$jac = ollize($jac);	
				  		  		else if($cat == 'zbf2l') $jac = zbf2lize($jac);
							
					  			//echo '<br />$p: '.$p.'<br />$alg2: '.parse($prem.$alg.$postm).'<br />$jac2: '.$jac.'<br />';
    	  						$res = insert(parse($prem), parse($alg), parse($postm), $suid, trim($jac)); 			
							//if(is_int($res) && $res != 0) {return array($res, $prem, $alg, $postm, $jac, jacubize($prem.$alg.$postm));}
							   if($res == '') return '';
			 	   	  		else $p++;	 
                  }
					 }
				}	
		  }	
	  }
   }
}
}
else return array('cloned');
return array('no_sid', $p);
*/

for($i=0;$i<count($pre_tab);$i++)											// pre
{
	for($j=0;$j<4;$j++)									// pre{"", U, U', U2}
	{
		if($cat == 'eg')																			
  		{
  			for($k=0;$k<4;$k++)							// pre{"", D, D', D2}
	  	   {
	  	   	$prem = trim($pre_tab2[0][$j].$pre_tab2[1][$k].$pre_tab[$i]); 
  				
  				for($l=0;$l<4;$l++)						// post{"", U, U', U2}
	 			{   		
					$jac = jacubize($prem.$alg.$post_tab[0][$l], 'normal');				
					$postm2 = trim(find_post2($jac));
					
					if($postm2 == '' || $postm2 == 'y' || $postm2 == "y'" || $postm2 == "y2") $ile = 1;
				   else $ile=4;
					
					for($m=0;$m<$ile;$m++)										// post2{"", U, U', U2}
					{		
						if($ile == 1) $postm = $post_tab[0][$l].$postm2;																
      				else $postm = $post_tab[0][$l].$postm2.$post_tab[0][$m];
					 	$jac = pocketize(jacubize($prem.$alg.$postm));
						//echo $p.' $pre: '.$prem.' $alg: '.$alg.' $postm: '.$postm.' $jac: '.$jac.'<br />';	 
					   $res = insert($prem, $alg, $postm, $suid, $jac, $if_ma, $cat); 			
 	  				 	if($res == '') return '';
  	  				 	else $p++;
														  			
					}
				}  			
  			}
      }
		
		// koniec eg
		
		
		else
		{
			$prem = trim($pre_tab2[0][$j].$pre_tab[$i]); 
  			//echo '$p: '.$p.' $prem: '.$prem.'<br />';	
			for($k=0;$k<4;$k++)							// post{"", U, U', U2}
			{   		
            $jac = jacubize($prem.$alg.$post_tab[0][$k], 'normal');				
				$postm2 = find_post2($jac);
					
				if($postm2 == '' || $postm2 == 'y' || $postm2 == "y'" || $postm2 == "y2") $ile = 1;
			 	else $ile=4;
								
				for($m=0;$m<$ile;$m++)										// post2{"", U, U', U2}
				{		
						if($ile == 1) $postm = $post_tab[0][$m].$postm2;																
						else $postm = $post_tab[0][$k].$postm2.$post_tab[0][$m];
		 				$jac = jacubize($prem.$alg.$postm);
				 		
				 		if($cat == 'oll')	$jac = ollize($jac);	
 		  				else if($cat == 'zbf2l') $jac = zbf2lize($jac);
						//echo $p.' $pre: '.$prem.' $alg: '.$alg.' $postm: '.$postm.' $jac: '.$jac.'<br />';		 
				 		$res = insert($prem, $alg, $postm, $suid, $jac, $if_ma);  			
			 			if($res == '') return '';
			 			else $p++;
														  			
				}
			}  	
		}	
	}
}

}

else { 
	if($uid != 1 && $if_ma == 'on')
	{	
	   $id = $klon;
		$query = "SELECT SID FROM `portal_algs` WHERE ID=$id;";
		$result = query($query);
		$row = mysql_fetch_row($result);
		$sid = $row[0];
		$cat = 1;
		$result = my_alg($sid, $id, $suid, $cat);
	}
	return 'cloned';
}
return 'no_sid';

}  

?>