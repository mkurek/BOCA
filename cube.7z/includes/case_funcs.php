<?php


function sortuj_mal($nazwa, $kolumna)
{
      $min=array();
		$temp=array();
		for ($a=0;$a<count($nazwa);$a++) 
		{
		 	 $min=$nazwa[$a];
			 $poz_min=$a;
			 $temp=$nazwa[$a];
		    for ($b=$a;$b<count($nazwa);$b++) 
  				 if ($nazwa[$b][$kolumna]>$min[$kolumna]) { $min=$nazwa[$b]; $poz_min=$b; }
	   
			 $nazwa[$a]=$min;
			 $nazwa[$poz_min]=$temp;
		}
		
		return $nazwa;	
}

function sortuj_ros($nazwa, $kolumna)
{
      $min=array();
		$temp=array();
		for ($a=0;$a<count($nazwa);$a++) 
		{
		 	 $min=$nazwa[$a];
			 $poz_min=$a;
			 $temp=$nazwa[$a];
			 for ($b=$a;$b<count($nazwa);$b++) 
  			 	  if ($nazwa[$b][$kolumna]<$min[$kolumna]) { $min=$nazwa[$b]; $poz_min=$b; }

          $nazwa[$a]=$min;
			 $nazwa[$poz_min]=$temp;
      }
 		
		return $nazwa;	
}

function cmp_ros($a, $b)
{
    if ($a[2] == $b[2]) {
        return 0;
    }
    return ($a[2] < $b[2]) ? -1 : 1;
}


function cmp_mal($a, $b)
{
    if ($a[7] == $b[7]) {
        return 0;
    }
    return ($a[7] > $b[7]) ? -1 : 1;
}


function licz_sid($sid)
{
	if(!is_array($sid))  return $sid;
	$temp1 = intval($sid[0]);
	$temp2 = intval($sid[1]);
	
	if($temp1 == $temp2) return $temp1; 
	
	if($temp1 < 473) {$temp = ceil(($temp1-1)/12+1500);}									// coll
	else if($temp1 > 472 && $temp2 < 761) $temp = ($temp1-473)/8+1540;				// \
	else if($temp1 == 761 && $temp2 == 762) $temp = 1576;									// |
	else if($temp1 == 763 && $temp2 == 766) $temp = 1577;									// |		f2l
	else if($temp1 == 767 && $temp2 == 768) $temp = 1578;									// |
	else if($temp1 == 769 && $temp2 == 772) $temp = 1579;									// |
	else if($temp1 == 773 && $temp2 == 774) $temp = 1580;									// /
	else if($temp1 > 858 && $temp2 < 901) $temp = ($temp1-859)/6+1581;				// ortega_co
	
	return $temp;
}



function moves($alg, $typ='htm')
{
      $alg = trim($alg) ;
		$ruchy = 0;

		preg_match_all("/[RLFBDUMSErlubdf]/", $alg, $wynik);
		$ruchy += count($wynik[0]);
		$wynik = '';

		preg_match_all("/[as]/", $alg, $wynik);
		$ext = count($wynik[0]);

		preg_match_all("/\d+/", $alg, $wynik);
		$dwojki = count($wynik[0]);
		$wynik = '';

		preg_match_all("/[MES]/", $alg, $wynik);
		$emki = count($wynik[0]);
		$wynik = '';

		preg_match_all("/[MES]2/", $alg, $wynik);
		$emki2 = count($wynik[0]);


		preg_match_all("/[as]2/", $alg, $wynik);
		$ext2 = count($wynik[0]);

		if($typ == 'htm') 
           $ruchy += $emki + $ext;		

		else if($typ == 'stm') 
			  $ruchy += $ext;	

      else if($typ == 'qtm') 
			  $ruchy += $dwojki + $emki + $emki2 + $ext + $ext2;

      else if($typ == 'qstm')
			  $ruchy += $dwojki + $ext + $ext2;

      $tab = explode(" ", $alg);
		$koniec = count($tab)-1;

		if($tab[$koniec] == "U" || $tab[$koniec] == "U\'" || $tab[$koniec] == "U2" || $tab[$koniec] == "U'") $ruchy--;
		if($tab[0] == "U" || $tab[0] == "U\'" || $tab[0] == "U2" || $tab[0] == "U'") $ruchy--;
		if($alg == 'brak algu') $ruchy = 0;

		return $ruchy;
}


function vote($sid, $id, $uid, $cat, $vote)
{
	$sid = licz_sid($sid);
	if(!can_vote($uid, $id, $sid, $cat)) return 'cant_vote';
	
	$query = "INSERT INTO portal_votes VALUES(NULL, $uid, $id, $sid, $cat, $vote);";
	
	$result = query($query);
	
	return true;
}


function my_alg($sid, $id, $uid, $cat)
{
	$sid = licz_sid($sid);
	$id = intval($id);
	$uid = intval($uid);
	$cat = intval($cat);
		
	$query = "SELECT * FROM portal_users_algs WHERE user_id=$uid AND sid=$sid AND cat=$cat;";
	
	$result = query($query);
	$row = mysql_fetch_row($result);
	
	if(mysql_num_rows($result) == 0) $query = "INSERT INTO portal_users_algs VALUES(NULL, $uid, $sid, $id, $cat);";	
	else $query = "UPDATE portal_users_algs SET alg_id=$id WHERE ID=$row[0];";
	
		
	$result = query($query);
	if($result != false) return true;
	else return 'mysql_error';	
}

function get_my_alg($sid, $uid, $cat)
{
	$sid = licz_sid($sid);
	$my_alg = '';
	if($uid == 1) return ''; 														// user = guest
	
	$query = "SELECT alg_id FROM portal_users_algs WHERE sid=$sid AND user_id=$uid AND cat=$cat;";
	$result = query($query);
	if(mysql_num_rows($result) == 0) return '';
	else
	{
		$row = mysql_fetch_row($result);
		$my_alg = $row[0];
	}
	
return $my_alg;	
}


function can_vote($uid, $id, $sid, $cat)
{
	if($uid == 1) return false; 										// Guest
	
	$query = "SELECT * FROM portal_votes WHERE user_id=$uid AND alg_id=$id AND sid=$sid AND cat=$cat;";
	
	$result = query($query);
	
	if(mysql_num_rows($result) == 0) return true;
	
	return false;
}


function votuj($tab, $sid, $uid, $cat)
{
	
	$algs = array();

	$sid = licz_sid($sid);

	for($i = 0;$i<count($tab);$i++)
	{	
		$alg_id = $tab[$i][0];	
		
		$query = "SELECT SUM(vote) FROM portal_votes WHERE alg_id=$alg_id AND sid=$sid AND cat=$cat;";
		$result = query($query);
		$row = mysql_fetch_row($result);
		
		if($row[0] != NULL || $row[0] != '') $tab[$i][7] = intval($row[0]); 								
		else $tab[$i][7] = 0;																		
		
		if(can_vote($uid, $tab[$i][0], $sid, $cat)) $tab[$i][8] = 1;					// can vote
		else $tab[$i][8] = 0;																		// can't vote
	}

	$my_alg = get_my_alg($sid, $uid, $cat);
	
	if($my_alg != '')
	{
		$i=0;
		while($tab[$i][0] != $my_alg) $i++;
		$algs = array_splice($tab, $i, 1);
	}
	
	if(count($tab)>1) usort($tab,  "cmp_mal");
	
	$temp = array();
	$max = count($tab);
	for($i=0;$i<$max;$i++)
	{                                                         
		if($tab[$i][7] != 0) {$temp[] = array_splice($tab, $i, 1); $i--;}
	}

	for($i= 0;$i<count($temp);$i++)
      $temp[$i] = $temp[$i][0];
	
	if(count($temp)>1) 
	{	
		$wynik = array();	
		$glosy = $temp[0][7];	
		$i=0;
		while(true)	
		{	  
		   $glosy = $temp[$i][7];
		     $poprz = $i;
			  $i++;		
			  $tym = array();
			  while($temp[$i][7] == $glosy) {$i++; if($i >= count($temp)) break;}
		    
		     if($i != $poprz-1)
		     {		     
		     	    for($j=$poprz;$j<$i;$j++)
		     	        $tym[] = $temp[$j]; 
  
			   usort($tym,  "cmp_ros");
			   $wynik = array_merge($wynik, $tym);
			  }
			  else $wynik[] = $temp[$poprz];

			  if($i >= count($temp)) break;
		}
		$temp = $wynik;
	}

   $algs = array_merge($algs, $temp);
	
	if(count($tab)>1) usort($tab,  "cmp_ros");
	
	for($i=0;$i<count($tab);$i++)
      $algs[] = $tab[$i];
		
	if($my_alg != '') $algs[0][9] = 'yes';
		
	return $algs;
}


function get_cat($sid1, $sid2)
{
      // jezeli sid1 i sid2 takie same
		if($sid1 == $sid2)
		{
		     if($sid1>0 && $sid1<473) $cat = 'zbll';
			  else if($sid1 > 472 && $sid1 < 775) $cat = 'zbf2l';
			  else if($sid1 > 774 && $sid1 < 796) $cat = 'pll';
			  else if($sid1 > 795 && $sid1 < 853) $cat = 'oll'; 
			  else if($sid1 > 852 && $sid1 < 859) $cat = 'ortega_cp';
			  else if($sid1 > 858 && $sid1 < 985) $cat = 'eg';
		}

		else
		{
			  if($sid1 > 472 && $sid2 < 775) $cat = 'f2l';
			  else if($sid1 > 0 && $sid2 < 473) $cat = 'coll';
			  else if($sid1 > 858 && $sid2 < 901) $cat = 'ortega_co';	
		}

		return $cat;
}


function get_imgcats($cat, $uid)
{
      global $imagecats;
		
		$tab = $imagecats[$cat];

      $query = "SELECT `subcat_name`, `value` FROM `portal_users_imgcats` WHERE `user_id`=$uid AND `cat_name`='$cat';";
		$result = query($query);	
			
		while($row = mysql_fetch_row($result))
		{
			$tab[$row[0]] = $row[1];
		}
		
		$result = array();
		
		foreach($tab as $key=>$value)
	      if($value == 1) $result[]=$key;		
	   

		return $result;
}


function get_prev($sid, $cat)
{
	if($sid[0] == $sid[1] && $sid[0]>1 && $cat != 'zzb' && $cat != 'zzd') return $sid[0]-1;
	
	else if($cat == 'zzb')
	{
		$sid = $sid[0];	
	
		if($sid%72 > 5 && $sid%72 < 57 && $sid<433)
		{
				
			if($sid%4 == 0 || $sid%6==0 || ($sid+1)%4==0) return $sid-1;
			else if($sid == 1) return '';
			else return $sid-9;
		}
		else if($sid < 433)
		{
    	
			if($sid%72 == 69) return $sid-13;
			if($sid%4==0 || ($sid+2)%4==0 || ($sid+1)%4==0) return $sid-1;
			if($sid-5%72 == 0) return $sid-5;
		}
		else
		{
				
			if(($sid > 437 && $sid < 441) || ($sid > 449 && $sid < 453) || ($sid > 459 && $sid < 463) || ($sid > 469 && $sid < 473) ) return $sid-1;
			else if($sid == 437) return $sid-5;
			else if($sid == 449) return $sid-9;
			else if($sid == 459 || $sid == 469) return $sid-7;
			else return '';	
		}
		
	}
	
	else if($cat == 'zzd')
	{
		$sid = $sid[0];	
		if($sid == 133 || $sid == 205 || $sid == 277 || $sid == 349 || $sid == 421) return $sid-61;
		else if($sid == 465) return 432;
		else if($sid == 61) return '';
		else return $sid-1;
	}
	
	
	else if($sid[0] > 12 && $sid[1] < 465) $prev = ($sid[0]-12).','.($sid[0]-1);
	else if($sid[0] == 465 && $sid[1] == 472) $prev = '457,464';
	else if($sid[0] > 479 && $sid[1] < 763) $prev = ($sid[0]-8).','.($sid[0]-1);
	else if($sid[0] == 763 && $sid[1] == 766) $prev = '761,762';
	else if($sid[0] == 767 && $sid[1] == 768) $prev = '763,766';
	else if($sid[0] == 769 && $sid[1] == 772) $temp = '767,768';
	else if($sid[0] == 773 && $sid[1] == 774) $temp = '769,772';	
	else if($sid[0]>864 && $sid[1] < 901) $prev = ($sid[0]-6).','.($sid[0]-1);
	else $prev = '';
	
	return $prev;	
}

function get_next($sid, $cat)
{
	if($sid[0] == $sid[1] && $sid[1] < 978 && $cat != 'zzb' && $cat != 'zzd') return $sid[0]+1;
	
	else if($cat == 'zzb')
	{
		$sid = $sid[0];			
		if($sid%72 > 0 && $sid%72 < 56 && $sid<433)
		{
				
			if(($sid+3)%4 == 0 || $sid%6==0 || ($sid+1)%4==0) return $sid+1;
			else return $sid+9;
		}
		else if($sid < 433)
		{
    	
			if($sid%72 == 56) return $sid+13;
			if(($sid+3)%4==0 || ($sid+2)%4==0 || ($sid+1)%4==0) return $sid+1;
			if($sid%72 == 0) return $sid+5;
		}
		else
		{
				
			if(($sid > 436 && $sid < 440) || ($sid > 448 && $sid < 452) || ($sid > 458 && $sid < 462) || ($sid > 468 && $sid < 472) ) return $sid+1;
			else if($sid == 440) return $sid+9;
			else if($sid == 452 || $sid == 462) return $sid+7;
			else return '';	
		}
		
	}
	
	else if($cat == 'zzd')
	{
		$sid = $sid[0];	
		if($sid == 72 || $sid == 144 || $sid == 216 || $sid == 288 || $sid == 360) return $sid+61;
		else if($sid == 432) return 465;
		else return $sid+1;
	}
	
	
	else if($sid[0] > 0 && $sid[1] < 445) $next = ($sid[1]+1).','.($sid[1]+12);
	else if($sid[0] == 445 && $sid[1] == 456) $next = '457,464';
	else if($sid[0] == 457 && $sid[1] == 464) $next = '465,472';
	else if($sid[0] > 472 && $sid[1] < 753) $next= ($sid[1]+1).','.($sid[1]+8);
	else if($sid[0] == 753 && $sid[1] == 760) $next = '761,762';
	else if($temp1 == 761 && $temp2 == 762) $next = '763,766';
	else if($sid[0] == 763 && $sid[1] == 766) $next = '767,768';
	else if($sid[0] == 767 && $sid[1] == 768) $next = '769,762';
	else if($sid[0] == 769 && $sid[1] == 772) $next = '773,774';	
	else if($sid[0] >858 && $sid[1] < 889) $next = ($sid[1]+1).','.($sid[1]+6);
	else if($sid[0] == 889 && $sid[1] == 894) $next = '895,898';
	else $next = '';
	
	return $next;
}

function get_bet($sid1, $sid2)									// funkcja przydatna tylko przy orientacji w ortedze - przekazujemy sid z cll'a a ona wyznacza jeszcze z pozostalych 2 kat z eg - potem obrabiane w petli w case.php
{
	if ($sid1 == $sid2) return array(array($sid1, $sid2));
	if($sid1< 859 || $sid2>898) return array(array($sid1, $sid2));
	else
	{
		$bet = array(
		array($sid1, $sid2),
		array(($sid1+40), ($sid2+40)),
		array(($sid1+80), ($sid2+80))
		);
		return $bet;	
	}
	
	
return '';
}


function tree_gen($sid, $cat, $cat_s)    								// sid -> liczba
{
	
	
	if($sid > 0 && $sid < 473)
	{
		if($cat == 'zzb') {$method = 'zz'; $chapter = 'b';}
		else if($cat == 'zzd') {$method = 'zz'; $chapter = 'd';} 
		else {$method = 'zb'; $chapter = 'zbll';}
		$orientation = ceil($sid/72);
		$permutation = ceil(($sid-($orientation-1)*72)/12);
	
		if($orientation == 7 && $sid > 464) $permutation = 4;
	
		if($cat == 'zzd') {if($orientation == 7) $permutation = 4; else $permutation =6;}
	}
	
	if($sid > 472 && $sid < 775)
	{
		$method = 'zb';
		$chapter = 'zbf2l';
		if($sid < 761) $subchapter = ceil(($sid-472)/16);
		else if($sid > 760 && $sid < 763) $subchapter = 19;
		else if($sid > 762 && $sid < 769) $subchapter = 20;
		else $subchapter = 21;	
	}
	
	if($sid > 774 && $sid < 796)
	{
		$method = 'fridrich';
		$chapter = 'pll';
		$if_case = true;
		$pll = $sid - 774;
	}
	
	if($sid > 795 && $sid < 853)
	{
		$method = 'fridrich';
		$chapter = 'oll';
		if($sid < 804)$subchapter = 'd';
		else if($sid > 803 && $sid < 831) $subchapter = 'l';
		else if($sid > 830 && $sid < 846) $subchapter = 'b';
		else $subchapter = 'p'; 
	}
	
	if($sid > 852 && $sid < 859)
	{
		$method = 'ortega';
		$chapter = 'cp';
	}
	
	if($sid > 858 && $sid < 979)
	{
		
		$method = 'eg';
		
		if($sid < 899) $chapter = 'n';
		else if($sid > 938) $chapter = 'b';
		else $chapter = 'r';
		
		if($chapter == 'n') $minus = 858;
		else if($chapter == 'r') $minus = 898;
		else $minus = 938;
		
		$subchapter = intval(ceil(($sid-$minus)/6));
	}
	
	if($sid > 1499 && $sid < 1540)
	{
		$method = 'coll';
		$orientation = ceil(($sid-1499)/6);
	}
	
	if($sid > 1539 && $sid < 1581)
	{
		$method = 'fridrich';
		$chapter = 'f2l';
	}
	
	if($sid > 1580 && $sid < 1587)
	{
		$method = 'ortega';
		$chapter = 'co';	
	}
	
	include "includes/arrays.php";
	//global $perm, $orient, $permh;
	
	include "includes/tree.php";
	
	return array($tree, $method, $chapter, $subchapter, $orientation, $permutation);
}



function get_cat_name($sid)
{
	if($sid>0 && $sid < 473) return 'zbll';
	else if($sid > 472 && $sid < 775) return 'zbf2l';
	else if($sid > 774 && $sid < 796) return 'pll';
	else if($sid > 775 && $sid < 853) return 'oll';
	else if($sid > 852 && $sid < 859) return 'ortega_cp';
	else if($sid > 858 && $sid < 979) return 'eg';
	
	else if($sid > 1499 && $sid < 1540) return 'coll';
	else if($sid > 1539 && $sid < 1581) return 'f2l';
	else if($sid > 1580 && $sid < 1588) return 'ortega_co';
	
	return '';	
}

?>